# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
import sqlite3
from .models import *
from django.contrib import messages

from .forms import *


def home(request):

	entries = wishes.objects.order_by('-date_posted')

	context = {'all_entries': entries}

	return render(request, 'home.html', context)

def add(request):

	if request.method == 'POST':
		
		# value = request.POST.['addwish']
		# username = request.POST.['username']

		# wishesObject = wishes.objects.create(wishname=value,username=username)
		# wishesObject.save() 

		NotesObj = wishes(wishname = request.POST['addwish'], username = request.POST['username'])
		NotesObj.save()

		# entries = wishes.objects.order_by('-date_posted')

		# context = {'all_entries': entries}

		return HttpResponseRedirect('home')



	else:

		return render(request, 'home.html')		



def delete_wish(request, id):

	instance = get_object_or_404(wishes, id=id)
	instance.delete()
	return redirect('home.html')



def edit(request, id):
	instance = get_object_or_404(wishes, id=id)
	
	if request.method == 'POST':
		form = PostForm(request.POST or None, instance=instance)
		if form.is_valid():
			form.save()
			return HttpResponseRedirect('home')
	else:
		form = PostForm(instance=instance)

	entries = wishes.objects.order_by('-date_posted')

	context = {'all_entries': entries}

	return render(request, 'edit.html', context)


