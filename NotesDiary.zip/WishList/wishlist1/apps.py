# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class Wishlist1Config(AppConfig):
    name = 'wishlist1'
