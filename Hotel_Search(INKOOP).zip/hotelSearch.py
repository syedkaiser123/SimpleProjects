import csv


#defining the logic for the serach operation

fields = []
cost = []
rating = []
states =[]
codes = []

T = {"Cost":[],"rating":[],"code":[]}
K = {"Cost":[],"rating":[],"code":[]}
M = {"Cost":[],"rating":[],"code":[]}

with open("hotels.csv","r") as r:

	reader = csv.reader(r)

	for row in reader:
		fields.append(row)


state = input("What is the state: ")
factor = input("cost or rating: ")
operation = input("Operation :")


for i in fields:
	for j in range(1,len(fields)-1):

		cost.append(int(fields[j][3]))
		rating.append(float(fields[j][4]))
		states.append(fields[j][2])
		codes.append(fields[j][2])

countT = 0
countK = 0
countM = 0
for m in range(1,len(fields)-1):

	if state == "Tamilnadu" and state == fields[m][2]:
		T["Cost"].append(int(fields[m][3]))
		countT+=1
	elif state == "Karnataka" and state == fields[m][2]:
		K["Cost"].append(int(fields[m][3]))
		countK+=1
	elif state == "Maharashtra" and state == fields[m][2]:
		M["Cost"].append(int(fields[m][3]))
		countM+=1

	if state == "Tamilnadu" and state == fields[m][2]:
		T["rating"].append(float(fields[m][4]))
		
	elif state == "Karnataka" and state == fields[m][2]:
		K["rating"].append(float(fields[m][4]))
	
	elif state == "Maharashtra" and state == fields[m][2]:
		M["rating"].append(float(fields[m][4]))

	if state == "Tamilnadu" and state == fields[m][2]:
		T["code"].append(fields[m][1])
		
	elif state == "Karnataka" and state == fields[m][2]:
		K["code"].append(fields[m][1])
	
	elif state == "Maharashtra" and state == fields[m][2]:
		M["code"].append(fields[m][1])
	




TC = T["Cost"]
KC = K["Cost"]
MC = M["Cost"]

TR = T["rating"]
KR = K["rating"]
MR = M["rating"]


max_cost = max(cost)
min_cost = min(cost)



max_rat = max(rating)
min_rat = min(rating)



if state == "Tamilnadu":
	avgCost_T = sum(TC)/countT
	avgRating_T = sum(TR)/countT

elif state == "Karnataka":	
	avgCost_K = sum(KC)/countK
	avgRating_K = sum(KR)/countK

elif state == "Maharashtra":
	avgCost_M = sum(MC)/countM
	avgRating_M = sum(MR)/countM

elif state == "india":
	avg_cost = sum(cost)/len(cost)
	avg_rat = sum(rating)/len(rating)



HotelCodeMax = ""
HotelCodeMin = ""
HotelCodeAvg = ""

for x in range(1,len(fields)-1):

	if state == "Tamilnadu":
		if state == fields[x][2] and int(fields[x][3]) == max(TC):		
			HotelCodeMax = fields[x][1]	
		elif state == fields[x][2] and int(fields[x][3]) == min(TC):
			HotelCodeMin = fields[x][1]
		elif state == fields[x][2] and int(fields[x][3]) == avgCost_T:
			HotelCodeAvg = fields[x][1]

	if state == "Karnataka":
		if state == fields[x][2] and int(fields[x][3]) == max(KC):		
			HotelCodeMax = fields[x][1]	
		elif state == fields[x][2] and int(fields[x][3]) == min(KC):
			HotelCodeMin = fields[x][1]
		elif state == fields[x][2] and int(fields[x][3]) == avgCost_K:
			HotelCodeAvg = fields[x][1]

	if state == "Maharashtra":
		if state == fields[x][2] and int(fields[x][3]) == max(MC):
			HotelCodeMax = fields[x][1]	
		elif state == fields[x][2] and int(fields[x][3]) == min(MC):
			HotelCodeMin = fields[x][1]
		elif state == fields[x][2] and int(fields[x][3]) == avgCost_M:
			HotelCodeAvg = fields[x][1]


	if state == "Tamilnadu":
		if state == fields[x][2] and float(fields[x][4]) == max(TR):		
			HotelCodeMax = fields[x][1]	
		elif state == fields[x][2] and float(fields[x][4]) == min(TR):
			HotelCodeMin = fields[x][1]
		elif state == fields[x][2] and float(fields[x][4]) == avgRating_T:
			HotelCodeAvg = fields[x][1]

	if state == "Karnataka":
		if state == fields[x][2] and float(fields[x][4]) == max(KR):
			HotelCodeMax = fields[x][1]	
		elif state == fields[x][2] and float(fields[x][4]) == min(KR):
			HotelCodeMin = fields[x][1]
		elif state == fields[x][2] and float(fields[x][4]) == avgRating_K:
			HotelCodeAvg = fields[x][1]

	if state == "Maharashtra":
		if state == fields[x][2] and float(fields[x][4]) == max(MR):
			HotelCodeMax = fields[x][1]	
		elif state == fields[x][2] and float(fields[x][4]) == min(MR):
			HotelCodeMin = fields[x][1]
		elif state == fields[x][2] and float(fields[x][4]) == avgRating_M:
			HotelCodeAvg = fields[x][1]



	if state == "india":
		if int(fields[x][3]) == max(cost):
			HotelCodeMax = fields[x][1]	
		elif int(fields[x][3]) == min(cost):
			HotelCodeMin = fields[x][1]
		elif int(fields[x][3]) == avg_cost:
			HotelCodeAvg = fields[x][1]

	elif state == "india" and float(fields[x][4]) == max_rat:
		HotelCodeMax = fields[x][1]
	elif state == "india" and float(fields[x][4]) == min_rat:
		HotelCodeMin = fields[x][1]
	elif state == "india" and float(fields[x][4]) == avg_rat:
		HotelCodeAvg = fields[x][1]




#performing the search operation


if factor == "cost" and operation == "highest":
	
	if state == "Tamilnadu":
		print("hotel with highest price in Tamilnadu is " + HotelCodeMax + " with price: ",max(TC))

	elif state == "Karnataka":
		print("hotel with highest price in Karnataka is " + HotelCodeMax + " with price: ",max(KC))

	elif state == "Maharashtra":
		print("hotel with highest price in Maharashtra is " + HotelCodeMax + " with price: ",max(MC))


elif factor == "cost" and operation == "cheapest":
	if state == "Tamilnadu":
		print("hotel with cheapest price in Tamilnadu is " + HotelCodeMin + " with price: ",min(TC))

	elif state == "Karnataka":
		print("hotel with cheapest price in Karnataka is " + HotelCodeMin + " with price: ",min(KC))

	elif state == "Maharashtra":
		print("hotel with cheapest price in Maharashtra is " + HotelCodeMin + " with price: ",min(MC))


elif factor == "cost" and operation == "average":
	if state == "Tamilnadu":
		print("Average cost of hotel in Tamilnadu is: ",avgCost_T)

	elif state == "Karnataka":
		print("Average cost of hotel in Karnataka is: ",avgCost_K)

	elif state == "Maharashtra":
		print("Average cost of hotel in Maharashtra is: ",avgCost_M)




if factor == "rating" and operation == "highest":
	if state == "Tamilnadu":
		print("Hotel with highest rating in Tamilnadu is " + HotelCodeMax + "with rating: ",max(TR))

	elif state == "Karnataka":
		print("Hotel with highest rating in Karnataka is " + HotelCodeMax + "with rating: ",max(KR))

	elif state == "Maharashtra":
		print("Hotel with highest rating in Maharashtra is " + HotelCodeMax + "with rating: ",max(MR))


elif factor == "rating" and operation == "cheapest":
	if state == "Tamilnadu":
		print("Hotel with cheapest rating in Tamilnadu is " + HotelCodeMin + "with rating: ",min(TR))

	elif state == "Karnataka":
		print("Hotel with cheapest rating in Karnataka is " + HotelCodeMin + "with rating: ",min(KR))

	elif state == "Maharashtra":
		print("Hotel with cheapest rating in Maharashtra is " + HotelCodeMin + "with rating: ",min(MR))


elif factor == "rating" and operation == "average":
	if state == "Tamilnadu":
		print("Average rating of hotel in Tamilnadu is: ",avgRating_T)

	elif state == "Karnataka":
		print("Average rating of hotel in Karnataka is: ",avgRating_K)

	elif state == "Maharashtra":
		print("Average rating of hotel in Maharashtra is: ",avgRating_M)



elif factor == "cost" and operation == "highest":
	if state == "india":
		print("Hotel with highest price in india is " +HotelCodeMax+ " with price: ",max_cost)

elif factor == "cost" and operation == "cheapest":
	if state == "india":
		print("Hotel with cheapest price in india is " +HotelCodeMin+" with price: ",min_cost)

elif factor == "cost" and operation == "average":
	if state == "india":
		print("Average price of hotel in india is: ",avg_cost)


elif factor == "rating" and operation == "highest":
	if state == "india":
		print("Hotel with highest rating in india is " +HotelCodeMax+ "with rating:  ",max_rat)

elif factor == "rating" and operation == "cheapest":
	if state == "india":
		print("Hotel with cheapest rating in india is " +HotelCodeMin+ " with rating: ",min_rat)

elif factor == "rating" and operation == "average":
	if state == "india":
		print("Average rating of hotel in india is ",avg_rat)