from flask import Flask, render_template, request, redirect

try:
	from googlesearch import search
except "ImportError":
	print("No modeule named 'Search' found")


app = Flask(__name__)
app.config["DEBUG"] = True



class Search:

	def __init__(self,string):

		self.string = string
		self.links = []

	

	def getItem(self):
		
		#searching the keyword and fetching each search result to append to links array
		for x in search(query=self.string, tld = "co.in", num = 20, stop = 20, pause = 2):

			self.links.append(x)

		#returning the links from links array
		return self.links





@app.route('/', methods = ['GET','POST'])
def home():

	if request.method == 'GET':
		return render_template('home.html')

	
	if request.method == 'POST':

		keyword = request.form.get('word')
		# print(keyword)

		find = Search(keyword)
		result = find.getItem()
		# print(result)

	return render_template('home.html', result=result)




if __name__ == "__main__":

	
	app.run()

