from flask import Flask, render_template, request, redirect
import urllib
import requests
from bs4 import BeautifulSoup

# try:
# 	from googlesearch import search
# except "ImportError":
# 	print("No modeule named 'Search' found")


app = Flask(__name__)
app.config["DEBUG"] = True

result = []

class Search:

	def __init__(self,string):

		self.string = string
		# self.links = []
		

	

	def getItem(self):
		
		#searching the keyword and fetching each search result to append to links array
		string = self.string
		URL = f'https://google.com/search?q={string}'


		

		try:
			response = requests.get(URL)


			if response.status_code == 200:

				soup = BeautifulSoup(response.content, "html.parser")
				# print(soup)
				
				div_tags = soup.find_all("div", attrs = {"class": "r"})

				print(div_tags)
				count = 0

				for i in div_tags:	
					print("helooooooooooooooooooooooooooooooo")

					anchor_tags = i.find_all('a')
					if anchor_tags:
						
						link = anchor_tags[0]['href']
						item = { 'link': link }
						result.append(item)
		except:
			print("request unsuccessful")

		#returning the links from links array
		print(result)
		return result





@app.route('/', methods = ['GET','POST'])
def home():

	if request.method == 'GET':
		return render_template('home.html')

	
	if request.method == 'POST':

		keyword = request.form.get('word')

		find = Search(keyword)
		result = find.getItem()


	return render_template('home.html', result=result)




if __name__ == "__main__":

	
	app.run()

