drop table if exists posts;
	create table posts (
		id integer primary key autoincrement,
		name text not null,
		content text not null
);


drop table if exists users;
	create table users (
		username text not null,
		email varchar not null,
		password varchar not null
);
