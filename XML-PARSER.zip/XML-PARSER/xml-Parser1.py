import csv
import requests
import xml.etree.ElementTree as ET

def loadurl():

	url = "https://www.w3schools.com/xml/simple.xml"

	response = requests.get(url)

	with open("FoodMenu.xml","wb") as f:

		f.write(response.content)



def parseXML(xmlfile):

	tree = ET.parse(xmlfile)

	root = tree.getroot()

	fooditems = []

	for item in root.findall("food"):
		
		food = {}

		for child in item:


			food[child.tag] = child.text.encode("utf8")
	

		fooditems.append(food)


	return fooditems




def savetoCSV(fooditems, filename):

	fields = ["name", "price", "description", "calories"]

	with open(filename, "w") as csvfile:

		writer = csv.DictWriter(csvfile, fieldnames = fields)
		writer.writeheader()
		writer.writerows(fooditems)
		


def main():

	loadurl()

	fooditems = parseXML("FoodMenu.xml")

	savetoCSV(fooditems, "foodmenu.csv")


if __name__ == "__main__":

	main()
