universe = {'SPACE': 'GORILLA','LAND': 'PANDA','WATER': 'OCTOPUS','ICE': 'MAMMOTH','AIR': 'OWL','FIRE': 'DRAGONS'}
# print(universe)

Alpha = []
All_kingdoms = []

for i in range(97,123):
	Alpha.append((chr(i).upper()))

Mssg = dict()
VALUES = []

with open('messages.txt','r') as f:

	line = f.readlines()							#reading input file
	
	for word in line:
		
		#creating a dictionary to store each message content as "Kingdom-name:Emblem"

		x = word.split()							
		kdm = x[0]
		msg = x[1]

		Mssg[kdm] = msg 

# print(Mssg)


#creating a list of 'Mssg' dictionary values
for key in Mssg.keys():

	VALUES.append(Mssg[key]) 

# print(VALUES)
# print(Alpha)

#performing the decryption of the messages sent by the SPACE kingdom
def send(flag):
	
	i = 0
	count = 0

	for kingdom in Mssg.keys():
		
		if kingdom in universe.keys():
			emblem = universe[kingdom]
			

			l = len(emblem)
			

			secret = VALUES[i]
			
			i += 1
			res = ""
			
			for k in secret:

				x = (int(Alpha.index(k)))-l
				
				res = res + Alpha[x]

			# print(res)

			for j in universe[kingdom]:
				
				if j in res:

					flag = True  
				else:
					flag = False
					break

			if flag == True:
				count += 1

		All_kingdoms.append(kingdom) 
	
	if count >= 3:
		print("SPACE",*All_kingdoms)
	else:
		print("NONE")


flag = False
send(flag) 